package com.codekrypt.greendao.db;


import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.codekrypt.greendao.db.Categories;

import org.greenrobot.greendao.database.Database;

import java.util.List;
//import android.app.main.java.com.codekrypt.greendao.db.Categories;
//import android.app.src.main.java.com.codekrypt.greendao.db.Datasets;


/**
 * Created by darcy on 2016-10-19.
 */
public class DatabaseHelper
{
    private final static String TAG = DatabaseHelper.class.getName();
    private static DatabaseHelper          instance;
    private        SQLiteDatabase          db;
    private        DaoMaster               daoMaster;
    private        DaoSession              daoSession;
    private        DatasetsDao             datasetsDao;
    private        CategoriesDao           categoriesDao;
    private        DaoMaster.DevOpenHelper helper;

    private DatabaseHelper(final Context context)
    {
        openDatabaseForWriting(context);
    }

    public synchronized static DatabaseHelper getInstance(final Context context)
    {
        if(instance == null)
        {
            instance = new DatabaseHelper(context);
        }

        return (instance);
    }

    public static DatabaseHelper getInstance()
    {
        if(instance == null)
        {
            throw new Error();
        }

        return (instance);
    }

    private void openDatabase()
    {
        daoMaster  = new DaoMaster(db);
        daoSession = daoMaster.newSession();
        datasetsDao    = daoSession.getDatasetsDao();
        categoriesDao  = daoSession.getCategoriesDao();
    }

    public void openDatabaseForWriting(final Context context)
    {
        helper = new DaoMaster.DevOpenHelper(context,
                "names.db",
                null);
        db = helper.getWritableDatabase();
        openDatabase();
    }

    public void openDatabaseForReading(final Context context)
    {
        final DaoMaster.DevOpenHelper helper;

        helper = new DaoMaster.DevOpenHelper(context,
                "names.db",
                null);
        db = helper.getReadableDatabase();
        openDatabase();
    }

    public void close()
    {
        helper.close();
    }

    public Datasets createDatasets(String Dataset, String Description, String Category, long CategoryID)
    {
        final Datasets name;

        name = new Datasets(null,Dataset, Description, Category, CategoryID);
        datasetsDao.insert(name);

        return (name);
    }
    public Categories createCategories(String category)
    {
        final Categories name;

        name = new Categories(null, category);
        categoriesDao.insert(name);
        return (name);
    }


    public Datasets getDatasetsFromCursor(final Cursor cursor)
    {
        final Datasets name;

        name = datasetsDao.readEntity(cursor,
                0);

        return (name);
    }

    public Categories getCategoriesFromCursor(final Cursor cursor)
    {
        final Categories name;

        name = categoriesDao.readEntity(cursor,
                0);

        return (name);
    }

    public Datasets getDatasetsByObjectId(final long id)
    {
        final List<Datasets> names;
        final Datasets       name;

        names = datasetsDao.queryBuilder().where(DatasetsDao.Properties.Id.eq(id)).limit(1).list();

        if(names.isEmpty())
        {
            name = null;
        }
        else
        {
            name = names.get(0);
        }

        return (name);
    }

    public Categories getCategoriesByObjectId(final long id)
    {
        final List<Categories> names;
        final Categories       name;

        names = categoriesDao.queryBuilder().where(DatasetsDao.Properties.Id.eq(id)).limit(1).list();

        if(names.isEmpty())
        {
            name = null;
        }
        else
        {
            name = names.get(0);
        }

        return (name);
    }

    public List<Datasets> getDatasets()
    {
        return (datasetsDao.loadAll());
    }

    public List<Categories> getCategories()
    {
        return (categoriesDao.loadAll());
    }

    public Cursor getDatasetsCursor()
    {
        final Cursor cursor;

        String orderBy = DatasetsDao.Properties.CategoryName.columnName + " ASC";
        cursor = db.query(datasetsDao.getTablename(),
                datasetsDao.getAllColumns(),
                null,
                null,
                null,
                null,
                orderBy);

        return (cursor);
    }
    public Cursor getCategoriesCursor()
    {
        final Cursor cursor;

        String orderBy = CategoriesDao.Properties.CategoryName.columnName + " ASC";
        cursor = db.query(categoriesDao.getTablename(),
                categoriesDao.getAllColumns(),
                null,
                null,
                null,
                null,
                orderBy);

        return (cursor);
    }

    public static void upgrade(final Database db,
                               final int      oldVersion,
                               final int      newVersion)
    {
    }

    public Categories getCategoryByObjectName(final String nm)
    {
        final List<Categories> categories;
        final Categories       category;

        categories = categoriesDao.queryBuilder().
                where(CategoriesDao.Properties.CategoryName.eq(nm)).limit(1).list();

        if(categories.isEmpty())
            category = null;
        else
            category = categories.get(0);

        return (category);
    }

    public Categories createCategory (final String nm)
    {
        final Categories tempCategory = getCategoryByObjectName (nm);
        if (tempCategory != null)
            return tempCategory;

        final Categories category;

        category = new Categories(null,
                nm);
        categoriesDao.insertOrReplace (category);

        return (category);
    }

    public Datasets createDataset (final String name, final String description, Categories cat) {
        final Datasets data;
        String catName = cat.getCategoryName ();
        Long   catId   = cat.getId ();
        data = new Datasets (null, name, description, catName, catId);

        datasetsDao.insertOrReplace (data);

        return data;
    }

    public Datasets createCategory_Dataset (final String catName, final String datasetName, final String description) {
        final Categories cat = createCategory (catName);
        final Datasets   ds  = createDataset (datasetName, description, cat);
        return ds;
    }

    public long getNumberOfDatasets()
    {
        return (datasetsDao.count());
    }

    public long getNumberOfCategories()
    {
        return (categoriesDao.count());
    }
}