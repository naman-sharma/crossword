package a00978420.comp3717.bcit.ca.assignment1;

import android.app.ListActivity;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.content.Loader;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.lang.String;

import com.codekrypt.greendao.db.CategoriesDao;
import com.codekrypt.greendao.db.DaoMaster;
import com.codekrypt.greendao.db.DaoSession;
import com.codekrypt.greendao.db.DatabaseHelper;
import com.codekrypt.greendao.db.LOG;
import com.codekrypt.greendao.db.LOGDao;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;

import org.greenrobot.greendao.database.Database;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends ListActivity {

    //Dao --> Data Access Object
    private LOGDao log_dao; // Sql access object
    private LOG temp_log_object; // Used for creating a LOG Object

    String log_text = "";  //Entered text data is save in this variable

    private final String DB_NAME = "logs-db";  //Name of Db file in the Device
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private SimpleCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialise DAO
        setupDb();

        adapter = new SimpleCursorAdapter (getBaseContext(),
                android.R.layout.simple_list_item_1,
                null,
                new String[] {
                        CategoriesDao.Properties.CategoryName.columnName,
                },
                new int[] {
                        android.R.id.text1,
                }, 0);

        setListAdapter (adapter);
        LoaderManager manager = getLoaderManager();
        manager.initLoader (0, null, new MainActivity.NameLoaderCallbacks());
    }

    //-----------f----------------------SQL QUERY Functions-----------------------------------------//
    public String getFromSQL() {
        List<LOG> log_list = log_dao.queryBuilder().orderDesc(LOGDao.Properties.Id).build().list();
        //Get the list of all LOGS in Database in descending order

        if (log_list.size() > 0) {  //if list is not null

            return log_list.get(0).getText();
            //get(0)--> 1st object
            // getText() is the function in LOG class
        }
        return "";
    }


    public void SaveToSQL(LOG log_object) {
        log_dao.insert(log_object);
    }
    //----------------------------***END SQL QUERY***---------------------------------------------//


    //-------------------------------DB Setup Functions---------------------------------------------//

    //Return the Configured LogDao Object
    public void setupDb() {
        DaoMaster.DevOpenHelper masterHelper = new DaoMaster.DevOpenHelper(this, DB_NAME, null); //create database db file if not exist
        SQLiteDatabase db = masterHelper.getWritableDatabase();  //get the created database db file
        DaoMaster master = new DaoMaster(db);//create masterDao
        DaoSession masterSession = master.newSession(); //Creates Session session
        DatabaseHelper helper = DatabaseHelper.getInstance (this);
        helper.openDatabaseForWriting (this);
        try {
            if (0 == helper.getNumberOfDatasets () && 0 == helper.getNumberOfCategories ()) {
                String line;
                String[] temp;
                BufferedReader br = new BufferedReader(new InputStreamReader(getAssets().open("dataSet")));

                while ((line = br.readLine()) != null) {
                    temp = line.split("\\|");

                    if (temp.length > 2)
                        helper.createCategory_Dataset (temp [2], temp [0], temp [1]);
                }
            }

        } catch (IOException ex) {
            Log.d ("Error", "IO Failure");
            ex.printStackTrace();
        }

    }

    public void placeData() throws IOException {

        BufferedReader br = new BufferedReader (new InputStreamReader(getAssets().open("dataSet.txt")));

        String line;
        String [] temp;
        while ((line = br.readLine()) != null)
            temp = line.split ("\\|");

    }



    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();

    }
    //-------------------------***END DB setup Functions***---------------------------------------//

    private class NameLoaderCallbacks
            implements LoaderManager.LoaderCallbacks<Cursor>
    {
        @Override
        public Loader<Cursor> onCreateLoader(final int    id,
                                             final Bundle args)
        {
            final Uri          uri;
            final CursorLoader loader;

            uri    = OpenDataContentProvider.CONTENT_URI;
            loader = new CursorLoader(MainActivity.this, uri, null, null, null, null);

            return (loader);
        }

        @Override
        public void onLoadFinished(final Loader<Cursor> loader,
                                   final Cursor         data)
        {
            adapter.swapCursor(data);
        }

        @Override
        public void onLoaderReset(final Loader<Cursor> loader)
        {
            adapter.swapCursor(null);
        }
    }
}