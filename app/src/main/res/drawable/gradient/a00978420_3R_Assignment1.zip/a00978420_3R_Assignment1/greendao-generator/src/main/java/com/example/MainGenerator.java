package com.example;

import de.greenrobot.daogenerator.DaoGenerator;
import de.greenrobot.daogenerator.Entity;
import de.greenrobot.daogenerator.Property;
import de.greenrobot.daogenerator.Schema;

public class  MainGenerator {
    public static void main(String[] args)  throws Exception {

        //place where db folder will be created inside the project folder
        Schema schema = new Schema(1,"com.codekrypt.greendao.db");


        //Entity i.e. Class to be stored in the database // ie table LOG
        final Entity one = schema.addEntity("Categories");
        final Entity two = schema.addEntity("Datasets");
        final DaoGenerator generator = new DaoGenerator();


        one.addIdProperty();
        one.addStringProperty("Category").notNull();

        two.addIdProperty();
        two.addStringProperty("Dataset").notNull();
        two.addStringProperty("Description").notNull();
        two.addStringProperty("Category").notNull();

        Property catFk = two.addLongProperty("CategoryID").notNull().getProperty();
        one.addToMany(two,catFk);



        //  ./app/src/main/java/   ----   com/codekrypt/greendao/db is the full path
        generator.generateAll(schema, "./app/src/main/java");

    }
}